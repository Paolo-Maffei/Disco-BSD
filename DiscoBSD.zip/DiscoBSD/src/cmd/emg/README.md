emg
===

emg, or Ersatz Mg, is a very tiny Emacs-like text editor created by
combining elements of Ersatz Emacs and Mg.

emg is distributed as part of the RetroBSD base system. This repo
is for development of emg. New releases are cut from this repo and
integrated into RetroBSD.

You can get a tarball of the latest release at
http://devio.us/~bcallah/emg/

emg is known to work on NetBSD as-is and AIX 5.1L with some small
tweaks, for those looking to get involved with emg development.

emg is Public Domain, because Ersatz Emacs and Mg are both Public
Domain and it would be insulting to all involved to change that.

=================================
Brian Callahan <bcallah@devio.us>
