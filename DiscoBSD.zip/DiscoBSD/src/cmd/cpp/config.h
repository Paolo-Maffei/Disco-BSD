#ifndef CONFIG_H__
#define CONFIG_H__

#define VERSSTR "cpp for RetroBSD"

#define HAVE_UNISTD_H 1
#define HAVE_SYS_WAIT_H 1
//#define HAVE_STRLCPY 1
//#define HAVE_STRLCAT 1

#endif // CONFIG_H__
