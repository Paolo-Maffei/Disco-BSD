main()
{
    printf ("Hello, SmallC World!\n");
}
