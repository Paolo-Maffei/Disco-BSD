Examples for LED cube 8x8x8.
