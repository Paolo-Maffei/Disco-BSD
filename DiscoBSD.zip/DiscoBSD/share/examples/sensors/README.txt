Examples for 37-in-1 sensor kit.

For details, see:
    https://github.com/sergev/RetroBSD-and-37-Sensor-Kit/wiki
