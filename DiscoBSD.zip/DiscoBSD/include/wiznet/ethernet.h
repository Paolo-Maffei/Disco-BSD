#ifndef ethernet_h
#define ethernet_h

#include <stdint.h>
#include "client.h"
#include "server.h"

#define MAX_SOCK_NUM 4

void ethernet_init (void);

#endif
