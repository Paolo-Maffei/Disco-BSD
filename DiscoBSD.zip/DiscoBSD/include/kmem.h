#ifndef _KMEM_H
#define _KMEM_H

extern dev_t kmemdev();

#endif
